import pymysql
import os
import numpy as np

db = pymysql.connect("localhost", "root", "", "Students")
cursor = db.cursor()

file = open('data.txt')
line = file.readline()
k = line.split()

vector = k[0].split(',')
list_to_float = np.array(list(map(lambda x:float(x),vector)))
number = '6500000'
name ='prapa'

bytes_feature = list_to_float.tostring()
cursor.execute('insert into Students values(%s,%s,%s)',(number,name,bytes_feature)) 
db.commit()